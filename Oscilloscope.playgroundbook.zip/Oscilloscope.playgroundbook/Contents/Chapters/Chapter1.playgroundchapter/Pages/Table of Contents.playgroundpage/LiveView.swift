import UIKit
import PlaygroundSupport

let v = SideViewController()
PlaygroundPage.current.liveView = v
