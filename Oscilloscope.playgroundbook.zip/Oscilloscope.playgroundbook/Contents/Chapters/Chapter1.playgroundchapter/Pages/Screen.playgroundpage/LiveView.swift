import UIKit
import PlaygroundSupport

let v = DisplayViewController()
PlaygroundPage.current.liveView = v

v.display.amplitude = 0.6
