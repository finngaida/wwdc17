
import UIKit
import PlaygroundSupport

let v = CathodeViewController()
PlaygroundPage.current.liveView = v
